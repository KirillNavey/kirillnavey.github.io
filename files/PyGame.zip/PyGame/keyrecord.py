import keyboard

events = keyboard.record('esc')

#keyboard.play(events)

input((list(keyboard.get_typed_strings(events))))